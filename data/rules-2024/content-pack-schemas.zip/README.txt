D&D Atlas — schema 1.0.0 / D&D 5e 2024

EN: Import a single pack.json, or select category arrays named exactly as in templates/ together. For separate arrays enter a unique pack_ ID and both names. Empty template files are intentionally blank and cannot be installed as an empty pack. The example is original homebrew, not official PHB content. Use the example to test linking and import. Schema files are not importable content. Do not import protected content without permission. Imported data stays in the browser profile, not an account-specific private vault. Existing Builder does not consume this catalog yet.

EL: Εισήγαγε ένα pack.json ή επίλεξε μαζί τους πίνακες JSON με τα ονόματα του templates/. Για ξεχωριστούς πίνακες συμπλήρωσε μοναδικό ID pack_ και τις δύο ονομασίες. Τα κενά πρότυπα πρέπει να συμπληρωθούν. Το παράδειγμα είναι ιδιοκατασκευή, όχι επίσημο περιεχόμενο του PHB. Τα schemas δεν εισάγονται ως δεδομένα. Εισήγαγε μόνο υλικό που δικαιούσαι να χρησιμοποιείς. Τα δεδομένα μένουν στο προφίλ του browser, όχι σε ιδιωτικό λογαριασμό. Ο υφιστάμενος Builder δεν χρησιμοποιεί ακόμη τον νέο κατάλογο.

Spell records may specify class_ids (catalog class IDs), school, casting_time, range, duration, components, ritual and concentration. The legacy Builder requires class_ids to show an imported spell.
